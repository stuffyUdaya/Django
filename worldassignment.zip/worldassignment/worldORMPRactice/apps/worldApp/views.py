from django.shortcuts import render
from . import models
from django.db.models import Count
# Create your views here.
def index(req):
    # cities = models.Countries.objects.filter(languagetocountry__language='slovene')
    # languages = models.Languages.objects.filter(language='slovene')
    # languages = models.Languages.objects.filter(language="Slovene").order_by('-percentage')

    # /##############################
    # cities = models.C.objects.().select_related('country')
    # & models.Countries.objects.filter()
    # countries = models.Countries.objects.filter(name="Mexico").select_related('')
    #3cities = models.Cities.objects.filter(population__gt= 500000,country__name="Mexico").order_by('-population')
    #4
    # cities = models.Languages.objects.filter(percentage__gt=89).order_by('-percentage')
    #5
    # cities = models.Countries.objects.filter(surface_area__lt=501,population__gt=100000)
    #6
    # cities = models.Countries.objects.filter(government_form="Constitutional Monarchy",capital__gt=200,life_expectancy__gt=75 )
    #7
    # cities = models.Cities.objects.filter(district = "Buenos Aires",population__gt=500000,country__name="Argentina")
    #8
    cities = models.Countries.objects.values('region').annotate(dcount=Count('code'))
    return render(req, 'worldApp/index.html', context={'cities':cities})
    # print cities
    # & models.Languages.objects.all()
    # print languages
    # # prints the queries
    # print (50*"*")
    # # print cities.query
    # print (50*"*")
    # print languages.query
    # print (50*"*")

    # context={'languages':languages})
