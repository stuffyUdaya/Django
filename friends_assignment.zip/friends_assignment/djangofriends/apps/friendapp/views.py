from django.shortcuts import render
from . import models
# Create your views here.
def index(req):
    # users = models.Users.objects.all()
    # users = models.Users.objects.filter(last_name="Rodriguez")
    # users = models.Users.objects.exclude(last_name = "Rodriguez")
    # users = models.Users.objects.filter(id__lte=7) | models.Users.objects.filter(id__gte=9)
    # users = models.Users.objects.filter(last_name="Rodriguez") | models.Users.objects.filter(first_name = "Daniel")
    # users = models.Users.objects.filter(last_name="Rodriguez") & models.Users.objects.exclude(first_name = "Madison")
    # users = models.Users.objects.exclude(first_name = "Daniel") & models.Users.objects.exclude(first_name = "Michael")
    # users = models.Users.objects.get(id=1)
    # users = models.Users.objects.get(last_name = 'Rodriguez'), get method doesn't work for values that return more than 1 means use get only for getting specific i'd or any other unique values.
    # users = models.Users.objects.get(id =10000), since there was no user matching with i'd :10000 so it returns users matching query doesn't exist.
    # users = models.Users.objects.all().order_by('first_name')
    # users = models.Users.objects.all().order_by('last_name').reverse()
    # friends = models.Friendships.objects.all()
    # friends = models.Friendships.objects.filter(user = 4) & models.Friendships.objects.all()
    # friends = models.Friendships.objects.filter(friend = 4 ) & models.Friendships.objects.all()
    friends = models.Friendships.objects.exclude(user =4).exclude(user =5).exclude(user =6).exclude(friend =4).exclude(friend =5).exclude(friend =6)

    print friends
    # print users
    # print users[0].id



    # users = models.Users.objects.order_by('first_name','desc')
    # print users.query
    # x=  users.first_name, users.last_name
    #
    # print x
    # context = {'users': users }
    context = {'friends': friends }
    return render(req, "friendapp/index.html",context)
    # (,context)
